Ecuador - Audio sampling test in basic
======================================

Experiment with sampling of data from audio cassette. Could be very loud. 

Load Basic 1Z016 (V1.0A)

RUN"
play file ecuador.mzf
play file ecuador_data.mzf
play file ecuador_usr.mzf

To return to basic press Ctrl+reset key (in some emulators as Ctrl+F12)
